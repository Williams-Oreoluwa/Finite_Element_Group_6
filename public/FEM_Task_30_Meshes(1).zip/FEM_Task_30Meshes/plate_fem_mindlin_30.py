"""
plate_fem_mindlin_30.py

Finite Element analysis of a thin rectangular plate using 3-node triangular
Reissner-Mindlin elements (w, theta_x, theta_y per node).

- Mesh: rectangle subdivided into nx x ny quads, each split into two triangles.
  We choose nx*ny = 15 => triangles = 30 (the user's request).
- Prints each element local stiffness (k_e) before assembly.
- Supports BCs per edge: 'C' (clamped), 'SS' (simply-supported approx), 'F' (free).
- Loads: uniform distributed load q (N/m^2) and concentrated point load P (N).
- Post-process: deflection contour, bending moments Mx, My, Mxy, top/bottom stresses.
- Validation: Navier solution for simply-supported plate under uniform load (series).
"""

import numpy as np
import matplotlib.pyplot as plt
from math import isclose, pi
from numpy.linalg import solve
import os
import pandas as pd

# ---------------------------
# Utility & FEM functions
# ---------------------------

def generate_rect_mesh(Lx, Ly, nx_quads=5, ny_quads=3):
    """
    Generate nodes and triangular elements for a rectangular domain [0,Lx]x[0,Ly].
    Uses nx_quads x ny_quads quadrilaterals, each split into two triangles.
    Returns nodes (n_nodes x 2) and elements (n_elems x 3) with node indices.
    For nx_quads=5, ny_quads=3, triangles = 2*5*3 = 30.
    """
    nx = nx_quads
    ny = ny_quads
    nx_nodes = nx + 1
    ny_nodes = ny + 1
    xs = np.linspace(0, Lx, nx_nodes)
    ys = np.linspace(0, Ly, ny_nodes)
    nodes = []
    for j in range(ny_nodes):
        for i in range(nx_nodes):
            nodes.append((xs[i], ys[j]))
    nodes = np.array(nodes)
    elements = []
    def nid(i, j):
        return j * nx_nodes + i
    for j in range(ny):
        for i in range(nx):
            n1 = nid(i, j)
            n2 = nid(i+1, j)
            n3 = nid(i+1, j+1)
            n4 = nid(i, j+1)
            # split quad (n1,n2,n3,n4) into triangles (n1,n2,n3) and (n1,n3,n4)
            elements.append([n1, n2, n3])
            elements.append([n1, n3, n4])
    elements = np.array(elements, dtype=int)
    return nodes, elements

def tri_area(coords):
    """Area of triangle given 3x2 coordinates"""
    x1,y1 = coords[0]; x2,y2 = coords[1]; x3,y3 = coords[2]
    return 0.5 * ((x2-x1)*(y3-y1) - (x3-x1)*(y2-y1))

def shape_gradients(coords):
    """
    For linear triangle shape functions N_i = a_i + b_i x + c_i y,
    return arrays b = [b1,b2,b3], c = [c1,c2,c3] such that dNi/dx = b_i, dNi/dy = c_i.
    """
    x1,y1 = coords[0]; x2,y2 = coords[1]; x3,y3 = coords[2]
    A2 = (x2 - x1)*(y3 - y1) - (x3 - x1)*(y2 - y1)  # = 2*Area
    if abs(A2) < 1e-12:
        raise ValueError("Degenerate triangle")
    b1 = (y2 - y3)/A2
    b2 = (y3 - y1)/A2
    b3 = (y1 - y2)/A2
    c1 = (x3 - x2)/A2
    c2 = (x1 - x3)/A2
    c3 = (x2 - x1)/A2
    return np.array([b1, b2, b3]), np.array([c1, c2, c3])

def element_stiffness_Mindlin(coords, E, nu, t, k_s=5/6):
    """
    Compute 9x9 element stiffness for 3-node triangular Mindlin element.
    DOF order per node: [w, theta_x, theta_y] => element vector size 9.
    Ke = ∫ (B_b^T D_b B_b + B_s^T D_s B_s) dA
    With linear shape functions, B matrices are constant over element.
    """
    A = abs(tri_area(coords))
    if A <= 0:
        raise ValueError("Element area non-positive")
    b, c = shape_gradients(coords)  # derivatives of shape functions
    # Bending B_b: 3 x 9 (rows: kappa_x, kappa_y, kappa_xy)
    B_b = np.zeros((3, 9))
    for i in range(3):
        # column indices
        col_theta_x = 3*i + 1
        col_theta_y = 3*i + 2
        B_b[0, col_theta_x] = b[i]  # d(theta_x)/dx
        B_b[1, col_theta_y] = c[i]  # d(theta_y)/dy
        B_b[2, col_theta_x] = c[i]  # d(theta_x)/dy
        B_b[2, col_theta_y] = b[i]  # d(theta_y)/dx
    # Shear B_s: 2 x 9 (rows: gamma_x, gamma_y)
    B_s = np.zeros((2, 9))
    for i in range(3):
        col_w = 3*i + 0
        col_theta_x = 3*i + 1
        col_theta_y = 3*i + 2
        B_s[0, col_w] = b[i]     # dN/dx -> contributes to d(w)/dx
        B_s[1, col_w] = c[i]     # dN/dy -> contributes to d(w)/dy
        B_s[0, col_theta_x] = 1  # theta_x enters gamma_x as +theta_x
        B_s[1, col_theta_y] = 1  # theta_y enters gamma_y as +theta_y
    # Material matrices
    D_b_factor = E * t**3 / (12.0 * (1 - nu**2))
    D_b = D_b_factor * np.array([[1.0, nu, 0.0],
                                 [nu, 1.0, 0.0],
                                 [0.0, 0.0, (1 - nu)/2.0]])
    G = E / (2 * (1 + nu))
    D_s = k_s * G * t * np.eye(2)
    # Element stiffness
    Ke_b = B_b.T @ D_b @ B_b * A
    Ke_s = B_s.T @ D_s @ B_s * A
    Ke = Ke_b + Ke_s
    return Ke, B_b, B_s, A

def assemble_global(nodes, elements, E, nu, t, save_k_path="k_matrices"):
    """
    Assemble global stiffness matrix and save each element's stiffness matrix.
    """
    n_nodes = nodes.shape[0]
    n_dof = 3 * n_nodes
    K = np.zeros((n_dof, n_dof))
    elem_data = []
    
    # Create directory for k matrices if it doesn't exist
    if not os.path.exists(save_k_path):
        os.makedirs(save_k_path)
    
    for e_idx, elem in enumerate(elements):
        coords = nodes[elem]
        Ke, B_b, B_s, A = element_stiffness_Mindlin(coords, E, nu, t)
        # Print local stiffness matrix (requirement)
        print(f"Element {e_idx} local stiffness k_e (9x9):\n", np.round(Ke, 6))
        
        # Save element stiffness matrix to file
        k_filename = os.path.join(save_k_path, f"k{e_idx+1}.txt")
        np.savetxt(k_filename, Ke, fmt='%.6e', delimiter=',')
        print(f"Saved element {e_idx+1} stiffness matrix to {k_filename}")
        
        # Assemble into global K
        dof_indices = []
        for n in elem:
            base = 3 * n
            dof_indices.extend([base+0, base+1, base+2])
        for i_local, I in enumerate(dof_indices):
            for j_local, J in enumerate(dof_indices):
                K[I, J] += Ke[i_local, j_local]
        elem_data.append({'Ke': Ke, 'elem': elem, 'B_b':B_b, 'B_s':B_s, 'A':A})
    return K, elem_data

def apply_boundary_conditions(K, F, nodes, edge_bcs, Lx, Ly):
    """
    edge_bcs: dict {'left':'C'/'SS'/'F', 'right':..., 'bottom':..., 'top':...}
    BC mapping approximations:
      - 'C' (clamped): w=0, theta_x=0, theta_y=0 on nodes of that edge
      - 'SS' (approx): w=0 and tangential rotation = 0 (approximation)
        For horizontal edge (y=0 or y=Ly): tangential along x => constrain theta_x=0
        For vertical edge (x=0 or x=Lx): tangential along y => constrain theta_y=0
      - 'F' (free): nothing constrained
    Returns modified K_reduced, F_reduced, list of fixed dofs
    """
    n_nodes = nodes.shape[0]
    fixed = []
    tol = 1e-8
    for n_idx, (x,y) in enumerate(nodes):
        # left edge:
        if abs(x - 0.0) < tol:
            bc = edge_bcs.get('left', 'F')
            if bc == 'C':
                fixed += [3*n_idx + 0, 3*n_idx + 1, 3*n_idx + 2]
            elif bc == 'SS':
                # tangential along y => constrain theta_y=0 (vertical edge, tangential=y)
                fixed += [3*n_idx + 0, 3*n_idx + 2]  # w and theta_y
        # right edge:
        if abs(x - Lx) < tol:
            bc = edge_bcs.get('right', 'F')
            if bc == 'C':
                fixed += [3*n_idx + 0, 3*n_idx + 1, 3*n_idx + 2]
            elif bc == 'SS':
                fixed += [3*n_idx + 0, 3*n_idx + 2]
        # bottom edge:
        if abs(y - 0.0) < tol:
            bc = edge_bcs.get('bottom', 'F')
            if bc == 'C':
                fixed += [3*n_idx + 0, 3*n_idx + 1, 3*n_idx + 2]
            elif bc == 'SS':
                # horizontal edge => tangential along x => constrain theta_x
                fixed += [3*n_idx + 0, 3*n_idx + 1]
        # top edge:
        if abs(y - Ly) < tol:
            bc = edge_bcs.get('top', 'F')
            if bc == 'C':
                fixed += [3*n_idx + 0, 3*n_idx + 1, 3*n_idx + 2]
            elif bc == 'SS':
                fixed += [3*n_idx + 0, 3*n_idx + 1]
    fixed = sorted(set(fixed))
    all_dofs = set(range(K.shape[0]))
    free = sorted(list(all_dofs - set(fixed)))
    # Reduce
    K_ff = K[np.ix_(free, free)]
    F_f = F[free]
    return K_ff, F_f, free, fixed

def apply_uniform_load(nodes, elements, q):
    """
    Uniform transverse load q (pressure, positive downward).
    Equivalent nodal loads for triangular element: w_dof receives q*A/3 at each node.
    Rotations receive no direct load from q assumed.
    Returns global F vector (size 3*n_nodes).
    """
    n_nodes = nodes.shape[0]
    F = np.zeros(3 * n_nodes)
    for elem in elements:
        # compute area
        coords = nodes[elem]
        A = abs(tri_area(coords))
        # distribute q*A to the three w DOFs equally
        for i_local, n in enumerate(elem):
            F[3*n + 0] += q * A / 3.0
    return F

def apply_point_load(F, nodes, P, xP, yP):
    """
    Apply concentrated point load P at (xP,yP) downward. We approximate by
    giving it to the nearest node's w DOF.
    """
    distances = np.linalg.norm(nodes - np.array([xP,yP]), axis=1)
    n_near = int(np.argmin(distances))
    F[3*n_near + 0] += P
    print(f"Applied point load P={P}N at nearest node {n_near} located {nodes[n_near]} (requested {xP,yP})")
    return F

# ---------------------------
# Postprocessing
# ---------------------------

def compute_element_curvatures_and_moments(nodes, elem_data, U_global, E, nu, t):
    """
    For each element compute curvature vector kappa = B_b * u_elem (only rotation DOFs used)
    and bending moments M = D_b * kappa.
    Returns arrays per element: centroid coords, Mx, My, Mxy, curvature vector.
    """
    D_b_factor = E * t**3 / (12.0 * (1 - nu**2))
    D_b = D_b_factor * np.array([[1.0, nu, 0.0],
                                 [nu, 1.0, 0.0],
                                 [0.0, 0.0, (1 - nu)/2.0]])
    results = []
    for ed in elem_data:
        elem = ed['elem']
        coords = nodes[elem]
        centroid = coords.mean(axis=0)
        # element nodal u
        u_e = np.zeros(9)
        for i,n in enumerate(elem):
            base = 3*n
            u_e[3*i:3*i+3] = U_global[base:base+3]
        # curvature
        B_b = ed['B_b']
        kappa = B_b @ u_e  # [kappa_x, kappa_y, kappa_xy]
        M = D_b @ kappa
        results.append({'elem':elem, 'centroid':centroid, 'kappa':kappa, 'M':M, 'A':ed['A']})
    return results

def nodal_quantity_from_element_centroids(nodes, elements, elem_results, quantity_key='M'):
    """
    Map element-centered quantity to nodal by averaging adjacent elements.
    quantity_key: 'M' -> vector [Mx,My,Mxy]
    Returns per-node averaged quantity (e.g. Mx at nodes).
    """
    n_nodes = nodes.shape[0]
    accum = np.zeros((n_nodes, 3))
    counts = np.zeros(n_nodes)
    for res in elem_results:
        M = res[quantity_key]
        for n in res['elem']:
            accum[n] += M
            counts[n] += 1
    # avoid division by zero
    for i in range(n_nodes):
        if counts[i] > 0:
            accum[i] /= counts[i]
    return accum  # n_nodes x 3

def navier_solution_center_deflection(a, b, t, E, nu, q, n_terms=15):
    """
    Classical Navier series for a simply supported rectangular plate under uniform load q.
    Returns center deflection w( a/2, b/2 ). Series over odd m,n.
    D = Et^3/(12(1-nu^2))
    w(x,y) = (16*q)/(pi^6*D) * sum_{m,n odd} sin(m*pi*x/a)sin(n*pi*y/b) / (m^2 n^2 ((m^2/a^2)+(n^2/b^2))^2)
    We'll evaluate at center where sin(m*pi/2) = 1 for odd m.
    """
    D = E * t**3 / (12.0 * (1 - nu**2))
    wsum = 0.0
    odd = list(range(1, 2*n_terms, 2))
    for m in odd:
        for n in odd:
            denom = (m**2 * n**2 * ((m**2 / a**2) + (n**2 / b**2))**2)
            wsum += 1.0 / denom
    w_center = (16.0 * q) / (pi**6 * D) * wsum
    return w_center

def save_results_to_excel(nodes, elements, w_nodes, M_nodal, sigma_top, sigma_bot, filename="plate_fem_results.xlsx"):
    """
    Save all results to an Excel file with multiple sheets.
    """
    with pd.ExcelWriter(filename, engine='openpyxl') as writer:
        # Node data
        node_data = pd.DataFrame({
            'Node_ID': range(len(nodes)),
            'X': nodes[:, 0],
            'Y': nodes[:, 1],
            'Deflection_w': w_nodes,
            'Mx': M_nodal[:, 0],
            'My': M_nodal[:, 1],
            'Mxy': M_nodal[:, 2],
            'Sigma_x_top': sigma_top[:, 0],
            'Sigma_y_top': sigma_top[:, 1],
            'Sigma_x_bottom': sigma_bot[:, 0],
            'Sigma_y_bottom': sigma_bot[:, 1]
        })
        node_data.to_excel(writer, sheet_name='Node_Results', index=False)
        
        # Element data
        element_list = []
        for i, elem in enumerate(elements):
            element_list.append({
                'Element_ID': i,
                'Node_1': elem[0],
                'Node_2': elem[1],
                'Node_3': elem[2]
            })
        element_data = pd.DataFrame(element_list)
        element_data.to_excel(writer, sheet_name='Element_Connectivity', index=False)
        
        # Summary data
        summary_data = pd.DataFrame({
            'Parameter': ['Max Deflection', 'Min Deflection', 'Max Mx', 'Min Mx', 'Max My', 'Min My'],
            'Value': [w_nodes.max(), w_nodes.min(), M_nodal[:, 0].max(), M_nodal[:, 0].min(), 
                     M_nodal[:, 1].max(), M_nodal[:, 1].min()]
        })
        summary_data.to_excel(writer, sheet_name='Summary', index=False)
    
    print(f"Results saved to {filename}")

# ---------------------------
# Main example run
# ---------------------------

def main():
    # Create directories for output
    if not os.path.exists("images"):
        os.makedirs("images")
    if not os.path.exists("excel_files"):
        os.makedirs("excel_files")
    if not os.path.exists("k_matrices"):
        os.makedirs("k_matrices")
    
    # ---------- User input / default parameters ----------
    Lx = 1.0      # plate length in x (m)
    Ly = 0.6      # plate length in y (m)
    t  = 0.01     # thickness (m)
    E  = 2.1e11   # Young's modulus (Pa) (steel)
    nu = 0.3      # Poisson's ratio
    q  = 1000.0   # uniform load (N/m^2)
    P_point = 0.0 # concentrated load (N)
    xP, yP = Lx/2, Ly/2  # point load location
    # Mesh choices: choose nx_quads * ny_quads = 15 -> 30 triangles
    nx_quads = 5
    ny_quads = 3
    # Edge BCs: 'C' (clamped), 'SS' (simply supported approx), 'F' (free)
    edge_bcs = {'left':'SS', 'right':'SS', 'bottom':'SS', 'top':'SS'}  # example: all simply supported
    # ----------------------------------------------------
    print("Generating mesh (30 triangles)...")
    nodes, elements = generate_rect_mesh(Lx, Ly, nx_quads=nx_quads, ny_quads=ny_quads)
    print(f"Nodes: {nodes.shape[0]}  Elements: {elements.shape[0]}")
    # Assemble global stiffness
    K, elem_data = assemble_global(nodes, elements, E, nu, t, save_k_path="k_matrices")
    n_dof = K.shape[0]
    # Global load vector from uniform load q (positive downward)
    F = apply_uniform_load(nodes, elements, q)
    if P_point != 0.0:
        F = apply_point_load(F, nodes, P_point, xP, yP)
    # Apply boundary conditions
    K_ff, F_f, free, fixed = apply_boundary_conditions(K, F, nodes, edge_bcs, Lx, Ly)
    print(f"Fixed DOFs: {fixed}\nFree DOFs: {len(free)}")
    # Solve reduced system
    U = np.zeros(n_dof)
    if K_ff.size == 0:
        raise RuntimeError("No free DOFs to solve for (check BCs).")
    U_f = solve(K_ff, F_f)
    # Place solution back into U
    for i, dof in enumerate(free):
        U[dof] = U_f[i]
    # Postprocessing: nodal deflections
    w_nodes = U[0::3]
    print("Nodal deflections (w) min/max:", w_nodes.min(), w_nodes.max())
    # Compute element curvatures and moments
    elem_results = compute_element_curvatures_and_moments(nodes, elem_data, U, E, nu, t)
    # Map moments to nodes by averaging
    M_nodal = nodal_quantity_from_element_centroids(nodes, elements, elem_results, 'M')
    Mx_nodes = M_nodal[:,0]
    My_nodes = M_nodal[:,1]
    Mxy_nodes = M_nodal[:,2]
    # Bending stresses at top (z=t/2) and bottom (z=-t/2):
    # sigma_x = -E*z/(1-nu^2) * (kappa_x + nu * kappa_y)
    # sigma_y = -E*z/(1-nu^2) * (nu * kappa_x + kappa_y)
    n_nodes = nodes.shape[0]
    sigma_top = np.zeros((n_nodes,2))  # sigma_x, sigma_y
    sigma_bot = np.zeros((n_nodes,2))
    # get nodal curvatures by averaging element curvatures (same approach)
    kappa_accum = np.zeros((n_nodes,3)); counts = np.zeros(n_nodes)
    for res in elem_results:
        k = res['kappa']
        for n in res['elem']:
            kappa_accum[n] += k
            counts[n] += 1
    for i in range(n_nodes):
        if counts[i] > 0:
            kappa = kappa_accum[i] / counts[i]
        else:
            kappa = np.zeros(3)
        kx, ky, kxy = kappa
        ztop =  t/2.0
        zbot = -t/2.0
        sigma_x_top = -E*ztop/(1-nu**2) * (kx + nu*ky)
        sigma_y_top = -E*ztop/(1-nu**2) * (nu*kx + ky)
        sigma_x_bot = -E*zbot/(1-nu**2) * (kx + nu*ky)
        sigma_y_bot = -E*zbot/(1-nu**2) * (nu*kx + ky)
        sigma_top[i,0] = sigma_x_top; sigma_top[i,1] = sigma_y_top
        sigma_bot[i,0] = sigma_x_bot; sigma_bot[i,1] = sigma_y_bot
    
    # Save results to Excel
    save_results_to_excel(nodes, elements, w_nodes, M_nodal, sigma_top, sigma_bot, 
                         filename="excel_files/plate_fem_results.xlsx")
    
    # Validation: Navier central deflection for simply supported plate under UDL q
    w_center_navier = navier_solution_center_deflection(Lx, Ly, t, E, nu, q, n_terms=11)
    # find FEM deflection at center (interpolate nearest node)
    distances = np.linalg.norm(nodes - np.array([Lx/2, Ly/2]), axis=1)
    idx_center = int(np.argmin(distances))
    w_center_fem = w_nodes[idx_center]
    percent_error = 100.0 * abs((w_center_fem - w_center_navier)/w_center_navier) if abs(w_center_navier) > 1e-12 else np.nan
    print(f"Navier center deflection (SS, series) = {w_center_navier:.6e} m")
    print(f"FEM center deflection (nearest node)     = {w_center_fem:.6e} m")
    print(f"Percent error = {percent_error:.3f}%")
    
    # Plotting: deflection contour
    import matplotlib.tri as mtri
    tri = mtri.Triangulation(nodes[:,0], nodes[:,1], triangles=elements)
    plt.figure(figsize=(8,4))
    plt.tricontourf(tri, w_nodes, 14)
    plt.colorbar(label='w (m)')
    plt.title('Deflection contour (w)')
    plt.xlabel('x (m)'); plt.ylabel('y (m)')
    plt.gca().set_aspect('equal', 'box')
    plt.tight_layout()
    plt.savefig('images/deflection_contour.png', dpi=300, bbox_inches='tight')
    
    # Plot Mx contour
    plt.figure(figsize=(8,4))
    plt.tricontourf(tri, Mx_nodes, 14)
    plt.colorbar(label='Mx (N·m/m)')
    plt.title('Bending moment Mx contour (nodal averaged)')
    plt.xlabel('x (m)'); plt.ylabel('y (m)')
    plt.gca().set_aspect('equal', 'box')
    plt.tight_layout()
    plt.savefig('images/mx_contour.png', dpi=300, bbox_inches='tight')
    
    # Plot My contour
    plt.figure(figsize=(8,4))
    plt.tricontourf(tri, My_nodes, 14)
    plt.colorbar(label='My (N·m/m)')
    plt.title('Bending moment My contour (nodal averaged)')
    plt.xlabel('x (m)'); plt.ylabel('y (m)')
    plt.gca().set_aspect('equal', 'box')
    plt.tight_layout()
    plt.savefig('images/my_contour.png', dpi=300, bbox_inches='tight')
    
    # Moment distribution along midlines (x = Lx/2 and y = Ly/2)
    # We'll sample nodes whose x near Lx/2 for vertical midline
    tol = min(Lx, Ly) / 200.0
    mask_xmid = np.abs(nodes[:,0] - Lx/2.0) < tol
    # if tol too small (coarse mesh), select nodes with minimal distance to x=midline
    if not mask_xmid.any():
        dists_x = np.abs(nodes[:,0] - Lx/2.0)
        min_d = dists_x.min()
        mask_xmid = np.abs(dists_x - min_d) < 1e-12
    xmid_nodes_idx = np.where(mask_xmid)[0]
    xmid_sorted = xmid_nodes_idx[np.argsort(nodes[xmid_nodes_idx,1])]
    plt.figure()
    plt.plot(nodes[xmid_sorted,1], Mx_nodes[xmid_sorted], '-o', label='Mx (x=L/2)')
    plt.plot(nodes[xmid_sorted,1], My_nodes[xmid_sorted], '-s', label='My (x=L/2)')
    plt.xlabel('y (m) along x=L/2'); plt.ylabel('Moment (N·m/m)'); plt.legend(); plt.grid(True)
    plt.title('Moments along vertical midline (x=L/2)')
    plt.savefig('images/moments_vertical_midline.png', dpi=300, bbox_inches='tight')
    
    # Horizontal midline (y = Ly/2)
    mask_ymid = np.abs(nodes[:,1] - Ly/2.0) < tol
    if not mask_ymid.any():
        dists_y = np.abs(nodes[:,1] - Ly/2.0)
        min_d = dists_y.min()
        mask_ymid = np.abs(dists_y - min_d) < 1e-12
    ymid_nodes_idx = np.where(mask_ymid)[0]
    ymid_sorted = ymid_nodes_idx[np.argsort(nodes[ymid_nodes_idx,0])]
    plt.figure()
    plt.plot(nodes[ymid_sorted,0], Mx_nodes[ymid_sorted], '-o', label='Mx (y=L/2)')
    plt.plot(nodes[ymid_sorted,0], My_nodes[ymid_sorted], '-s', label='My (y=L/2)')
    plt.xlabel('x (m) along y=L/2'); plt.ylabel('Moment (N·m/m)'); plt.legend(); plt.grid(True)
    plt.title('Moments along horizontal midline (y=L/2)')
    plt.savefig('images/moments_horizontal_midline.png', dpi=300, bbox_inches='tight')
    
    # Save mesh plot
    plt.figure()
    plt.triplot(tri, color='black', linewidth=0.5)
    plt.plot(nodes[:,0], nodes[:,1], 'o', markersize=3)
    plt.title('Finite Element Mesh')
    plt.xlabel('x (m)'); plt.ylabel('y (m)')
    plt.gca().set_aspect('equal', 'box')
    plt.savefig('images/mesh_plot.png', dpi=300, bbox_inches='tight')
    
    # Save stress plots
    plt.figure(figsize=(8,4))
    plt.tricontourf(tri, sigma_top[:,0], 14)
    plt.colorbar(label='σ_x (Pa)')
    plt.title('Top surface stress σ_x contour')
    plt.xlabel('x (m)'); plt.ylabel('y (m)')
    plt.gca().set_aspect('equal', 'box')
    plt.tight_layout()
    plt.savefig('images/stress_x_top.png', dpi=300, bbox_inches='tight')
    
    plt.figure(figsize=(8,4))
    plt.tricontourf(tri, sigma_bot[:,0], 14)
    plt.colorbar(label='σ_x (Pa)')
    plt.title('Bottom surface stress σ_x contour')
    plt.xlabel('x (m)'); plt.ylabel('y (m)')
    plt.gca().set_aspect('equal', 'box')
    plt.tight_layout()
    plt.savefig('images/stress_x_bottom.png', dpi=300, bbox_inches='tight')
    
    print("All images saved to 'images' folder")
    print("All Excel files saved to 'excel_files' folder")
    print("All stiffness matrices saved to 'k_matrices' folder")
    
    plt.show()

if __name__ == "__main__":
    main()